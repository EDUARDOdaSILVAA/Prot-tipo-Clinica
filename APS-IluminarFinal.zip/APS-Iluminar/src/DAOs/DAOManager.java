/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOs;

/**
 *
 * @author eduardo
 */
public class DAOManager {

    public static SessaoDAO getSessaoDAO() {
        return SessaoDAO.getInstance();
    }

    public static SalaDAO getSalaDAO() {
        return SalaDAO.getInstance();
    }

    public static PacienteDAO getPacienteDAO() {
        return PacienteDAO.getInstance();
    }

    public static FuncionarioDAO getFuncionarioDAO() {
        return FuncionarioDAO.getInstance();
    }
    
    // Outros métodos previstos no diagrama (Ex: Pagamento, Relatório) seriam adicionados aqui
}