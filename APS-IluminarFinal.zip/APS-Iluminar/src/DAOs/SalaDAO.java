/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOs;

/**
 *
 * @author eduardo
 */
import Entidades.Sala;
import java.util.ArrayList;
import java.util.List;

public class SalaDAO {
    private static SalaDAO instance;
    private List<Sala> salas = new ArrayList<>();

    private SalaDAO() {
        // Carga inicial de dados (Mock)
        salas.add(new Sala(101, 5));
        salas.add(new Sala(102, 10));
        salas.add(new Sala(103, 4));
    }

    public static SalaDAO getInstance() {
        if (instance == null) instance = new SalaDAO();
        return instance;
    }

    public List<Sala> findAll() { return salas; }
}
