/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOs;

/**
 *
 * @author eduardo
 */
import Entidades.Funcionario;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioDAO {
    private static FuncionarioDAO instance;
    private List<Funcionario> funcionarios = new ArrayList<>();

    private FuncionarioDAO() {}

    public static FuncionarioDAO getInstance() {
        if (instance == null) instance = new FuncionarioDAO();
        return instance;
    }

    public void create(Funcionario f) {
        funcionarios.add(f);
    }
    
    // ESTE É O MÉTODO QUE O COMPILADOR ESTAVA RECLAMANDO
    public List<Funcionario> findAll() { 
        return funcionarios; 
    }
    
    public Funcionario findByCpf(String cpf) {
        return funcionarios.stream()
                .filter(f -> f.getCpf().equals(cpf))
                .findFirst().orElse(null);
    }

    // Adicionado para suportar exclusão completa
    public boolean delete(String cpf) {
        return funcionarios.removeIf(f -> f.getCpf().equals(cpf));
    }
}