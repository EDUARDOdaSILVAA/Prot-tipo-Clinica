/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOs;

/**
 *
 * @author eduardo
 */
import Entidades.Paciente;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {
    private static PacienteDAO instance;
    private List<Paciente> pacientes = new ArrayList<>();

    private PacienteDAO() {}

    public static PacienteDAO getInstance() {
        if (instance == null) instance = new PacienteDAO();
        return instance;
    }

    public void create(Paciente p) { pacientes.add(p); }
    
    public List<Paciente> findAll() { return pacientes; }
    
    public Paciente findByCpf(String cpf) {
        return pacientes.stream().filter(p -> p.getCpf().equals(cpf)).findFirst().orElse(null);
    }
    
    public boolean delete(String cpf) {
        return pacientes.removeIf(p -> p.getCpf().equals(cpf));
    }
}