/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOs;

/**
 *
 * @author eduardo
 */
import Entidades.Sessao;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SessaoDAO {
    private static SessaoDAO instance;
    private List<Sessao> sessoes = new ArrayList<>();

    private SessaoDAO() {}

    public static SessaoDAO getInstance() {
        if (instance == null) instance = new SessaoDAO();
        return instance;
    }

    public void create(Sessao sessao) {
        sessoes.add(sessao);
        System.out.println("[DB] Sessão salva com ID: " + sessao.getIdSessao());
    }

    public void update(Sessao sessao) {
        // Atualiza referência em memória
    }

    public Sessao findById(String id) {
        return sessoes.stream().filter(s -> s.getIdSessao().equals(id)).findFirst().orElse(null);
    }

    // GARANTA QUE ESTE MÉTODO EXISTA
    public List<Sessao> findAll() { return sessoes; }

    public List<Sessao> findByHorario(LocalDateTime dataHora) {
        List<Sessao> encontradas = new ArrayList<>();
        for (Sessao s : sessoes) {
            if (s.getDataHora().isEqual(dataHora)) {
                encontradas.add(s);
            }
        }
        return encontradas;
    }

    public boolean delete(String id) {
        return sessoes.removeIf(s -> s.getIdSessao().equals(id));
    }
}