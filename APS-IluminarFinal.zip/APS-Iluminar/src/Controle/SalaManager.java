/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle;

/**
 *
 * @author eduardo
 */
import DAOs.DAOManager;
import Entidades.Sessao;
import Entidades.Sala;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

public class SalaManager {

    // Método correspondente à Operação 7.14 listaSalasDisponiveis() e 7.3 verificarDisponibilidadeSalas
    public List<Sala> verificarDisponibilidadeSalas(LocalDateTime dataHora) {
        // 1. Busca todas as salas via DAO (Correção arquitetural)
        List<Sala> todasSalas = DAOManager.getSalaDAO().findAll();
        
        // 2. Busca sessões agendadas no horário via DAO
        List<Sessao> sessoesAgendadas = DAOManager.getSessaoDAO().findByHorario(dataHora);
        
        List<Sala> disponiveis = new ArrayList<>(todasSalas);

        // 3. Remove salas ocupadas
        for (Sessao s : sessoesAgendadas) {
            disponiveis.removeIf(sala -> sala.getNumero() == s.getSala().getNumero());
        }
        
        System.out.println("Log: Verificando disponibilidade para " + dataHora + ". Salas livres: " + disponiveis.size());
        return disponiveis;
    }
}