/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle;

/**
 *
 * @author eduardo
 */

import DAOs.DAOManager;
import Entidades.Paciente;
import Entidades.Sessao;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

public class RelatorioManager {

    // Implementa Contrato 7.8: solicitarGerarRelatorio
    public String gerarRelatorio(String cpfPaciente) {
        // Busca o paciente
        Paciente paciente = DAOManager.getPacienteDAO().findByCpf(cpfPaciente);
        if (paciente == null) {
            return "Erro: Paciente não encontrado para o CPF: " + cpfPaciente;
        }

        // Busca todas as sessões
        List<Sessao> sessoes = DAOManager.getSessaoDAO().findAll();
        
        // Filtra sessões apenas deste paciente
        List<Sessao> historico = sessoes.stream()
                .filter(s -> s.getPaciente().getCpf().equals(cpfPaciente))
                .collect(Collectors.toList());

        // Implementa Contrato 7.9: exibirPrevisualizacao (montando a String de retorno)
        StringBuilder relatorio = new StringBuilder();
        relatorio.append("\n===================================\n");
        relatorio.append("       RELATÓRIO DE EVOLUÇÃO       \n");
        relatorio.append("===================================\n");
        relatorio.append("Paciente: ").append(paciente.getNome()).append("\n");
        relatorio.append("CPF: ").append(paciente.getCpf()).append("\n");
        relatorio.append("Total de Sessões: ").append(historico.size()).append("\n");
        relatorio.append("-----------------------------------\n");

        if (historico.isEmpty()) {
            relatorio.append("Nenhuma sessão registrada neste período.\n");
        } else {
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
            
            for (Sessao s : historico) {
                relatorio.append("Data/Hora: ").append(s.getDataHora().format(fmt)).append("\n");
                
                // Verifica se o terapeuta não é nulo para evitar erro
                String nomeTerapeuta = (s.getTerapeuta() != null) ? s.getTerapeuta().getNome() : "Não informado";
                relatorio.append("Terapeuta: ").append(nomeTerapeuta).append("\n");
                
                relatorio.append("Atividades Realizadas:\n");
                if (s.getAtividades().isEmpty()) {
                    relatorio.append("  (Nenhuma atividade registrada)\n");
                } else {
                    for (String atv : s.getAtividades()) {
                        relatorio.append("  - ").append(atv).append("\n");
                    }
                }
                relatorio.append("-----------------------------------\n");
            }
        }
        relatorio.append("             FIM DO RELATÓRIO      \n");
        relatorio.append("===================================\n");
        
        return relatorio.toString();
    }
}