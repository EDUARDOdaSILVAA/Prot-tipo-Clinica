/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle;

/**
 *
 * @author eduardo
 */
import DAOs.DAOManager;
import Entidades.*;
import java.time.LocalDateTime;
import java.util.UUID;

// Lógica de Agendamento e Execução da Sessão 
public class SessaoManager {
    private SalaManager salaManager = new SalaManager();
    private Sessao sessaoAtual; // Estado da sessão ativa na memória

    // --- Caso de Uso: Agendar Horário ---

    // Operação 7.1: iniciarAgendamento 
    // Operação 7.2: marcarSessao 
    public boolean agendarSessao(Paciente p, Funcionario t, LocalDateTime dataHora, Sala sala) {
        // 1. Verifica conflito (RNF11 implícita)
        var salasLivres = salaManager.verificarDisponibilidadeSalas(dataHora);
        
        boolean salaEstaLivre = salasLivres.stream().anyMatch(s -> s.getNumero() == sala.getNumero());
        
        if (!salaEstaLivre) {
            System.out.println("Erro: A Sala " + sala.getNumero() + " está ocupada neste horário.");
            return false;
        }

        // 2. Cria a sessão (RF09)
        String idUnico = UUID.randomUUID().toString().substring(0, 8); // RF12
        Sessao novaSessao = new Sessao(idUnico, p, t, sala, dataHora);

        // 3. Salva via DAO
        DAOManager.getSessaoDAO().create(novaSessao);
        System.out.println("Sucesso: Sessão agendada para " + p.getNome() + " com " + t.getNome());
        return true;
    }

    // --- Caso de Uso: Atender Paciente ---

    // Operação 7.4: iniciarSessao 
    public void iniciarSessao(String idSessao) {
        Sessao s = DAOManager.getSessaoDAO().findById(idSessao);
        if (s != null) {
            this.sessaoAtual = s;
            System.out.println("Sessão " + idSessao + " INICIADA.");
        } else {
            System.out.println("Erro: Sessão não encontrada.");
        }
    }

    // Operação 7.5: registrarAtividade 
    public void registrarAtividade(String atividade, int desempenho, String obs) {
        if (sessaoAtual != null) {
            sessaoAtual.adicionarAtividade(atividade, desempenho, obs);
            System.out.println("Atividade registrada: " + atividade);
            // Salva estado parcial
            DAOManager.getSessaoDAO().update(sessaoAtual);
        } else {
            System.out.println("Erro: Nenhuma sessão em andamento.");
        }
    }

    // Operação 7.6: finalizarSessao 
    public void finalizarSessao() {
        if (sessaoAtual != null) {
            sessaoAtual.finalizar();
            DAOManager.getSessaoDAO().update(sessaoAtual);
            System.out.println("Sessão " + sessaoAtual.getIdSessao() + " FINALIZADA com sucesso.");
            this.sessaoAtual = null;
        }
    }
}
