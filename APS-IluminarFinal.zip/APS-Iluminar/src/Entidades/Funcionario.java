/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author eduardo
 */
public class Funcionario {
    private String cpf;
    private String nome;
    private String cargo;
    private double salario; 

    public Funcionario(String cpf, String nome, String cargo, double salario) {
        this.cpf = cpf;
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
    }

    public String getCpf() { return cpf; }
    public String getNome() { return nome; }
    
    @Override
    public String toString() {
        return "Func.: " + nome + " (" + cargo + ") | CPF: " + cpf + " | Salário: R$" + salario;
    }
}