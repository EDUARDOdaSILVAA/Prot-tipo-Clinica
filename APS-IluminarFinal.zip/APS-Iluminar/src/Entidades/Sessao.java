/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author eduardo
 */
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Sessao {
    private String idSessao;
    private Paciente paciente;
    private Funcionario terapeuta; 
    private Sala sala;
    private LocalDateTime dataHora;
    private boolean realizada;
    private List<String> atividades;
    private String observacoes;

    public Sessao(String idSessao, Paciente paciente, Funcionario terapeuta, Sala sala, LocalDateTime dataHora) {
        this.idSessao = idSessao;
        this.paciente = paciente;
        this.terapeuta = terapeuta;
        this.sala = sala;
        this.dataHora = dataHora;
        this.realizada = false;
        this.atividades = new ArrayList<>();
    }

    public void adicionarAtividade(String atividade, int desempenho, String obs) {
        this.atividades.add("Atividade: " + atividade + " | Nota: " + desempenho + " | Obs: " + obs);
    }

    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
    public void finalizar() { this.realizada = true; }
    
    // Getters
    public String getIdSessao() { return idSessao; }
    public Paciente getPaciente() { return paciente; }
    public Sala getSala() { return sala; }
    public LocalDateTime getDataHora() { return dataHora; }
    public List<String> getAtividades() { return atividades; }
    public Funcionario getTerapeuta() { return terapeuta; }
   
}