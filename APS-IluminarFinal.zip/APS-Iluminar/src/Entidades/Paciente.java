/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author eduardo
 */
public class Paciente {
    private String cpf;
    private String nome;
    private int idade;
    private String escola; 

    public Paciente(String cpf, String nome, int idade, String escola) {
        this.cpf = cpf;
        this.nome = nome;
        this.idade = idade;
        this.escola = escola;
    }

    public String getCpf() { return cpf; }
    public String getNome() { return nome; }
    
    @Override
    public String toString() {
        return "Paciente: " + nome + " | CPF: " + cpf + " | Idade: " + idade + " | Escola: " + escola;
    }
}