/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author eduardo
 */
public class Sala {
    private int numero;
    private int capacidade;

    public Sala(int numero, int capacidade) {
        this.numero = numero;
        this.capacidade = capacidade;
    }

    public int getNumero() { return numero; }
    
    public int getCapacidade() { return capacidade; }

    @Override
    public String toString() { return "Sala " + numero + " (Cap: " + capacidade + ")"; }
}