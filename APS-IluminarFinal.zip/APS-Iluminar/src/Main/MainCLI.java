/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

/**
 *
 * @author eduardo
 */
import Controle.SalaManager;
import Controle.SessaoManager;
import DAOs.DAOManager;
import Entidades.Funcionario;
import Entidades.Paciente;
import Entidades.Sala;
import Entidades.Sessao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class MainCLI {

    private static Scanner scanner = new Scanner(System.in);
    private static SessaoManager sessaoManager = new SessaoManager();
    private static SalaManager salaManager = new SalaManager();
    private static Controle.RelatorioManager relatorioManager = new Controle.RelatorioManager();

    public static void main(String[] args) {
        // Carga inicial de dados para teste 
        inicializarDados();

        int opcao = 0;
        do {
            System.out.println("\n=== SISTEMA ILUMINAR ===");
            System.out.println("1. Gerenciar Pacientes (CRUD)");
            System.out.println("2. Gerenciar Funcionários (CRUD)");
            System.out.println("3. Agendar Sessão");
            System.out.println("4. Realizar Sessão (Atendimento)");
            System.out.println("5. Listar Agendamentos");
            System.out.println("6. Gerar Relatório do Paciente");
            System.out.println("0. Sair");
            System.out.print("Escolha: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                opcao = -1;
            }

            switch (opcao) {
                case 1:
                    menuPaciente();
                    break;
                case 2:
                    menuFuncionario();
                    break;
                case 3:
                    menuAgendamento();
                    break;
                case 4:
                    menuAtendimento();
                    break;
                case 5:
                    listarSessoes();
                    break;
                case 6:
                    menuRelatorio();
                    break;
                case 0:
                    System.out.println("Encerrando...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
    }

    // --- CRUD PACIENTE
    private static void menuPaciente() {
        System.out.println("\n--- GESTÃO DE PACIENTES ---");
        System.out.println("1. Cadastrar");
        System.out.println("2. Listar");
        System.out.println("3. Excluir");
        System.out.print("Opção: ");
        int op = Integer.parseInt(scanner.nextLine());

        if (op == 1) {
            System.out.print("CPF: ");
            String cpf = scanner.nextLine();
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Idade: ");
            int idade = Integer.parseInt(scanner.nextLine());
            System.out.print("Escola: ");
            String escola = scanner.nextLine();

            Paciente p = new Paciente(cpf, nome, idade, escola);
            DAOManager.getPacienteDAO().create(p);
            System.out.println("Paciente cadastrado com sucesso!");
        } else if (op == 2) {
            List<Paciente> lista = DAOManager.getPacienteDAO().findAll();
            if (lista.isEmpty()) {
                System.out.println("Nenhum paciente cadastrado.");
            } else {
                lista.forEach(System.out::println);
            }
        } else if (op == 3) {
            System.out.print("CPF do Paciente a excluir: ");
            String cpf = scanner.nextLine();
            if (DAOManager.getPacienteDAO().delete(cpf)) {
                System.out.println("Paciente removido.");
            } else {
                System.out.println("Paciente não encontrado.");
            }
        }
    }

    // --- CRUD FUNCIONÁRIO 
    private static void menuFuncionario() {
        System.out.println("\n--- GESTÃO DE FUNCIONÁRIOS ---");
        System.out.println("1. Cadastrar");
        System.out.println("2. Listar");
        System.out.println("3. Excluir");
        System.out.print("Opção: ");
        int op = Integer.parseInt(scanner.nextLine());

        if (op == 1) {
            System.out.print("CPF: ");
            String cpf = scanner.nextLine();
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Cargo: ");
            String cargo = scanner.nextLine();
            System.out.print("Salário: ");
            double salario = Double.parseDouble(scanner.nextLine());

            Funcionario f = new Funcionario(cpf, nome, cargo, salario);
            DAOManager.getFuncionarioDAO().create(f);
            System.out.println("Funcionário cadastrado!");
        } else if (op == 2) {
            List<Funcionario> lista = DAOManager.getFuncionarioDAO().findAll();
            if (lista.isEmpty()) {
                System.out.println("Nenhum funcionário cadastrado.");
            } else {
                lista.forEach(System.out::println);
            }
        } else if (op == 3) {
            System.out.print("CPF do Funcionário a excluir: ");
            String cpf = scanner.nextLine();
            // Assumindo que você criou o método delete no FuncionarioDAO
            // DAOManager.getFuncionarioDAO().delete(cpf); 
            System.out.println("Funcionalidade de exclusão simulada.");
        }
    }

    // --- CASO DE USO: AGENDAR HORÁRIO 
    private static void menuAgendamento() {
        System.out.println("\n--- NOVO AGENDAMENTO ---");

        // Selecionar Paciente
        System.out.print("Digite o CPF do Paciente: ");
        String cpfP = scanner.nextLine();
        Paciente p = DAOManager.getPacienteDAO().findByCpf(cpfP);
        if (p == null) {
            System.out.println("Paciente não encontrado!");
            return;
        }

        // Selecionar Terapeuta
        System.out.print("Digite o CPF do Terapeuta: ");
        String cpfF = scanner.nextLine();
        Funcionario f = DAOManager.getFuncionarioDAO().findByCpf(cpfF);
        if (f == null) {
            System.out.println("Funcionário não encontrado!");
            return;
        }

        // Data e Hora
        System.out.print("Data e Hora (dd/MM/yyyy HH:mm): ");
        String dataStr = scanner.nextLine();
        LocalDateTime dataHora = LocalDateTime.parse(dataStr, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));

        // Verificar Salas Disponíveis 
        List<Sala> salasLivres = salaManager.verificarDisponibilidadeSalas(dataHora);
        if (salasLivres.isEmpty()) {
            System.out.println("Nenhuma sala disponível neste horário.");
            return;
        }

        System.out.println("Salas Disponíveis:");
        for (Sala s : salasLivres) {
            System.out.println("Sala " + s.getNumero() + " (Capacidade: " + s.getCapacidade() + ")"); // Assumindo getter
        }

        System.out.print("Digite o número da sala desejada: ");
        int numSala = Integer.parseInt(scanner.nextLine());
        Sala salaEscolhida = salasLivres.stream()
                .filter(s -> s.getNumero() == numSala)
                .findFirst()
                .orElse(null);

        if (salaEscolhida != null) {
            boolean sucesso = sessaoManager.agendarSessao(p, f, dataHora, salaEscolhida);
            if (sucesso) {
                System.out.println("Agendamento realizado com sucesso!");
            }
        } else {
            System.out.println("Sala inválida.");
        }
    }
    // --- CASO DE USO: FAZER RELATÓRIO ---

    private static void menuRelatorio() {
        System.out.println("\n--- GERAR RELATÓRIO ---");
        System.out.print("Digite o CPF do Paciente: ");
        String cpf = scanner.nextLine();

        // Chama a operação do contrato
        String textoRelatorio = relatorioManager.gerarRelatorio(cpf);

        System.out.println(textoRelatorio);
    }

    // --- CASO DE USO: ATENDER PACIENTE  ---
    private static void menuAtendimento() {
        System.out.println("\n--- ATENDIMENTO (REALIZAR SESSÃO) ---");
        System.out.print("ID da Sessão: ");
        String id = scanner.nextLine();

        sessaoManager.iniciarSessao(id);

        String continuar = "S";
        while (continuar.equalsIgnoreCase("S")) {
            System.out.print("Descrição da Atividade: ");
            String atv = scanner.nextLine();
            System.out.print("Desempenho (1-5): ");
            int nota = Integer.parseInt(scanner.nextLine());
            System.out.print("Observação: ");
            String obs = scanner.nextLine();

            sessaoManager.registrarAtividade(atv, nota, obs);

            System.out.print("Registrar outra atividade? (S/N): ");
            continuar = scanner.nextLine();
        }

        sessaoManager.finalizarSessao();
    }

    private static void listarSessoes() {
        List<Sessao> sessoes = DAOManager.getSessaoDAO().findAll();
        System.out.println("\n--- LISTA DE SESSÕES ---");
        for (Sessao s : sessoes) {
            System.out.println("ID: " + s.getIdSessao()
                    + " | Data: " + s.getDataHora()
                    + " | Paciente: " + s.getPaciente().getNome());
        }
    }

    private static void inicializarDados() {
        // Dados pré-carregados para facilitar testes
        DAOManager.getPacienteDAO().create(new Paciente("111", "Joãozinho", 8, "Escola A"));
        DAOManager.getFuncionarioDAO().create(new Funcionario("222", "Dra. Ana", "Terapeuta", 5000));
        // Salas já são carregadas no construtor do SalaDAO
    }
}
